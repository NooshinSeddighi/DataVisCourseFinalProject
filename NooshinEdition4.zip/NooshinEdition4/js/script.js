const pieConfig = {
    showAll: true
}
// d3.json('data/data_v2.json').then(data => {

//     console.log("script started");

// let mainBodyDiv = d3.select('body')
//     .append('div');

// let upperSection = mainBodyDiv
//     .append('div')
//     .classed('upperSection', true);

// let tableDiv = upperSection
//     .append('div')
//     .classed('tableFormat', true);

// let table = new Table(data);

// table.createTable();

//     //let criteriaDiv = upperSection
//     //    .append('div')
//     //    .classed('criteriaFormat', true);

//     //let criteria = new Criteria(data);

//     //criteria.createCriteria();

//     let lowerSection = mainBodyDiv
//         .append('div')
//         .classed('lowerSection', true);

//     let detailsDiv = lowerSection
//         .append('div')
//         .classed('detailsFormat', true);

//     let details = new Details(data);

//     details.createDetails();

//     let scatterDiv = lowerSection
//         .append('div')
//         .classed('scatterFormat', true);

//     let scatterPlot = new Scatter(data);

//     scatterPlot.createScatter();

// })
function DoTheThing() {
    // console.log("doing the thing");
    // console.log(criteria);

    function convertToBoolean(value) {
        return value.toLowerCase() === 'yes'
    }

    function parseWorkingHour(workingHours) {
        return workingHours.split(",")
    }

    d3.csv(`data/uHungryRestaurants.csv`)
        .then(dataOutput => {
            d3.csv(`data/Departments.csv`).then(departments => {

                const restaurants = []

                dataOutput.forEach(element => {

                    const restaurant = restaurants.find(item => item.name === element.name)

                    const menuItem = {
                        dataType: 'menuItem',
                        name: element.nameOfFood,
                        menuName: element.menuList,
                        price: element.price,
                        inside: element.inside,
                    }

                    const menuListItem = {
                        dataType: 'menuListItem',
                        name: element.menuList,
                        numberOfItems: element.numberOfItems,
                        items: [menuItem]
                    }

                    if (restaurant) {
                        // Add menu item to the found restaurant
                        const foundList = restaurant.menuList.find(item => item.name === menuListItem.name)

                        if (foundList) {
                            foundList.items.push(menuItem)
                        } else {
                            restaurant.menuList.push(menuListItem)
                        }

                    } else {
                        // Add restaurant to list
                        const restaurantObj = {
                            dataType: 'restaurant',
                            name: element.name,
                            building: element.building,
                            type: element.type,
                            address: element.address,
                            phoneNumber: element.phoneNumber,
                            latitude: element.latitude,
                            longitude: element.longitude,
                            googleMapLink: element.googleMapLink,
                            workingHour: parseWorkingHour(element.workingHour),
                            dineIn: convertToBoolean(element['dine-in']),
                            takeOut: convertToBoolean(element.takeOut),
                            delivery: convertToBoolean(element.delivery),
                            rating: element.rating,
                            reviews: element.reviews,
                            website: element.website,
                            menuPhoto: element.menuPhoto,
                            menuList: [menuListItem]
                        }

                        restaurants.push(restaurantObj)
                    }
                });

                restaurants.forEach(rest => {
                    const menu = []
                    rest.menuList.forEach(menuListItem => menu.push(...menuListItem.items.map(menuItem => menuItem)))
                    const avgPrice = menu.reduce(
                        (accumulator, item) => accumulator + parseFloat(item.price),
                        0
                    ) / menu.length;
                    rest.avgPrice = isNaN(avgPrice) ? 0 : avgPrice
                    if (rest.avgPrice < 3.33) {
                        rest.avgPriceSymbol = "$"
                    } else if (rest.avgPrice >= 3.33 && rest.avgPrice < 6.66) {
                        rest.avgPriceSymbol = "$$"
                    } else {
                        rest.avgPriceSymbol = "$$$"
                    }
                })

                let filteredRestaurants = restaurants;

                // Check for criteria
                if (criteria.userRating != '') {
                    filteredRestaurants = restaurants.filter(function (d) { return parseFloat(d.rating) >= parseFloat(criteria.userRating); })
                }

                // console.log(filteredRestaurants);
                console.log(restaurants);
                // console.log(departments);

                d3.select("#dropdown-container select").remove()

                const pieButton = d3.select("#filter-pie-btn")

                const dropDown = d3.select("#dropdown-container")
                    .append("select")
                    .attr("class", "selection custom-select")
                    .attr("name", "department-list")

                dropDown.selectAll("option")
                    .data(departments)
                    .enter()
                    .append("option")
                    .text((d) => d.department)
                    .attr("value", d => d.department)

                const pie = new Pie(filteredRestaurants, departments[0])

                pieButton.on("click", event => {
                    console.log(event);
                    pieConfig.showAll = !pieConfig.showAll
                    pie.reDraw(pieConfig.showAll)
                })

                // Create SVGs with proper data
                if (criteria.userRating != '') {
                    const table = new Table(filteredRestaurants, departments[0])
                    const leaflet = new Leaflet(filteredRestaurants, departments)
                    dropDown.on("change", (event) => {
                        const dep = departments.find(item => item.department = event.target.value)
                        table.changeDepartment(dep)
                        pie.changeDepartment(dep)
                    });
                }
                else {
                    const table = new Table(restaurants, departments[0])
                    const leaflet = new Leaflet(restaurants, departments)
                    dropDown.on("change", (event) => {
                        const dep = departments.find(item => item.department = event.target.value)
                        table.changeDepartment(dep)
                        pie.changeDepartment(dep)
                    });
                }



            })
        })

}