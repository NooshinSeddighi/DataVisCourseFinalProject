class Leaflet {
    constructor(data, departments) {
        this.restaurants = [...data]
        this.data = [...data]

        this.margin = { top: 10, bottom: 10, left: 30, right: 30 };
        this.width = 400;
        this.height = 400;

        this.createLeaflet();
    }

    //Script referenced from d3 - graph - gallery.com / graph / bubblemap_leaflet_basic.html
    createLeaflet() {
        // mapid is the id of the div where the map will appear
        document.getElementById('mapid').remove();
        d3.select("#map-container").append("span").attr("id", "mapid");

        var map = L
            .map('mapid')
            .setView([40.765, -111.842], 15);   // center position + zoom

        // Add a tile to the map = a background. Comes from OpenStreetmap
        L.tileLayer(
            'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>',
            maxZoom: 19,
        }).addTo(map);

        // Add a svg layer to the map
        L.svg().addTo(map);

        d3.select("#mapid")
            .select("svg")
            .selectAll("circle")
            .data(this.data)
            .enter()
            .append("circle")
            .attr("cx", function (d) { return map.latLngToLayerPoint([d.latitude, d.longitude]).x })
            .attr("cy", function (d) { return map.latLngToLayerPoint([d.latitude, d.longitude]).y })
            .attr("r", 10)
            .style("fill", "blue")
            .attr("stroke", "blue")
            .attr("stroke-width", 2)
            .attr("fill-opacity", .7)
            .attr("pointer-events", "visible")

        // If the user change the map (zoom or drag), I update circle position:
        map.on("moveend", update)

        function update() {
            d3.selectAll("circle")
                .attr("cx", function (d) { return map.latLngToLayerPoint([d.latitude, d.longitude]).x })
                .attr("cy", function (d) { return map.latLngToLayerPoint([d.latitude, d.longitude]).y })
        }

    }
}